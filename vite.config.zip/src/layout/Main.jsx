import React, { useEffect } from 'react';
import Particles from 'react-particles-js';
import Footer from "../shared/Footer/Footer";
import Navbar from "../shared/Navbar/Navbar";
import { Outlet } from "react-router-dom";

const Main = () => {
  useEffect(() => {
    Particles.init({ selector: '.background' });
  }, []);

  const particleParams = {
    particles: {
      number: {
        value: 50
      },
      size: {
        value: 3
      }
    },
    interactivity: {
      events: {
        onhover: {
          enable: true,
          mode: "repulse"
        }
      }
    }
  };

  return (
    <div>
      <Particles params={particleParams} />
      <Navbar />
      <Outlet />
      <Footer />
    </div>
  );
};

export default Main;
